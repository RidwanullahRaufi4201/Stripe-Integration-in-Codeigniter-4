<?php
 
namespace App\Controllers;
 
use App\Controllers\BaseController;
use App\Models\PaymentInfo;
use Stripe;

 
class StripeController extends BaseController
{
    public function index()
    {
        $pay=new PaymentInfo();

        $data['payment']=$pay->findAll();
        return view('checkout',['data'=>$data]);
    }
 
    public function createCharge()
    {
        $amount=$this->request->getPost('amount');
        $currency=$this->request->getPost('currency');

        Stripe\Stripe::setApiKey(getenv('stripe.secret'));
        $data=[
            "amount" => $amount,
            "currency" => $currency,
            "source" => $this->request->getVar('stripeToken'),
            "description" => "testing stripe"
        ];
           
           
           $pay=new PaymentInfo();
           $pay->insert($data);

        
          return redirect()->back()->with('success', 'Payment Successful!');
  
    }


    public function deleteTransction($id)
    {
        $pay=new PaymentInfo();
        $pay->delete($id);
        return redirect()->back()->with('delete', 'Transaction deleted successfully!');
           
    }
     
}