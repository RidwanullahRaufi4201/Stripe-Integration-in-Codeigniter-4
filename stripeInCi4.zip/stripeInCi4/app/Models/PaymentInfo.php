<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentInfo extends Model
{
    protected $table      = 'paymentdetails';
    protected $allowedFields = ['amount', 'currency','source','description'];

}