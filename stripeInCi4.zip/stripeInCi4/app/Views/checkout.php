<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <style>
       .show-view .debug-view-path{
            display: none !important;
        }
    </style>
</head>
<body>
    <div class="container p-5">
        <div class="row justify-content-around">
            <div class="col-4">
                <div class="card">
                    <div class="card-body">
                        <?php if (session()->getFlashdata('success')) : ?>
                            <div 
                                style="color: green;
                                    border: 2px green solid;
                                    text-align: center;
                                    padding: 5px;margin-bottom: 10px;">
                                Payment Successful!
                            </div>
                        <?php endif ?>
                        <form id='checkout-form' method='post' action="<?php echo base_url('/stripe/create-charge'); ?>">             
                            <input type='hidden' name='stripeToken' id='stripe-token-id'>                              
                            <label for="card-element" class="mb-5 text-center" >Checkout Forms</label>
                    
                            <br>
                            <div class="form-group">
                                <label for="">Amount</label>
                                <input type="number" name="amount" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Currency</label>
                                <input type="text" name="currency" class="form-control">
                            </div>
                            <div id="card-element" class="form-control" ></div>
                           
                            <button 
                                id='pay-btn'
                                class="btn btn-success mt-3"
                                type="button"
                                style="margin-top: 20px; width: 100%;padding: 7px;"
                                onclick="createToken()">PAY 
                            </button>
                        <form>
                    </div>
                </div>
            </div>
            <?php if($data['payment']){ ?>
            <div class="col-md-5">
               
            <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Amount</th>
      <th scope="col">Currency</th>
      <th scope="col">Sourse</th>
      <th scope="col">Description</th>
      <th scope="col">Delete </th>
    </tr>
  </thead>
  <tbody>
       <?php
          foreach($data['payment'] as $pa){
       ?>
       <tr>
         <td><?php echo $pa['amount'] ?></td>
         <td><?php echo $pa['currency'] ?></td>
         <td><?php echo $pa['source'] ?></td>
         <td><?php echo $pa['description'] ?></td>
         <td ><a class="btn btn-danger" href="delete/<?php echo $pa['id'] ?>">Delete</a></td>
       </tr>
      <?php }?>
  </tbody>
</table>

<?php if (session()->getFlashdata('delete')) : ?>
                            <div 
                                style="color: red;
                                    border: 2px red solid;
                                    text-align: center;
                                    padding: 5px;margin-bottom: 10px;">
                                 <?php echo session()->getFlashdata('delete'); ?>
                            </div>
                        <?php endif ?>
          <!-- <div>
            <ol>
            <?php
         // foreach($data['payment'] as $pa){
       ?>
       <li>
         <div><span class="fw-bold">Amount </span> <?php // echo $pa['amount'] ?></div>
         <div><span class="fw-bold">Currency </span> <?php //echo $pa['currency'] ?></div>
         <div><span class="fw-bold">Source </span><?php //echo $pa['source'] ?></div>
         <div><span class="fw-bold">Description </span> <?php // echo $pa['description'] ?></div>
          </li>
      <?php ////}?>
            </ul>
          </div> -->
            </div>
            <?php }?>
        </div>


    
    </div>
  
    <script src="https://js.stripe.com/v3/" ></script>
    <script>
        var stripe = Stripe("<?php echo getenv('stripe.key') ?>");
        var elements = stripe.elements();
        var cardElement = elements.create('card');
        cardElement.mount('#card-element');
   
        function createToken() {
           document.getElementById("pay-btn").disabled = true;
            stripe.createToken(cardElement).then(function(result) {
   
                   
                if(typeof result.error != 'undefined') {
                    document.getElementById("pay-btn").disabled = false;
                    alert(result.error.message);
                }
   
                // creating token success
                if(typeof result.token != 'undefined') {
                    document.getElementById("stripe-token-id").value = result.token.id;
                    document.getElementById('checkout-form').submit();
                }
            });
        }
    </script>
</body>
</html>